<div align="center">
  <h1 align="center">Google Clone</h1>
    <h3>
      <a href="#">Lenke til prosjektet </a>
      <!-- https://github.com/roykenvgs/test -->
      <!-- https://github.com/roykenvgs/detertest -->
    </h3>
</div>

## Innholdsfortegnelse

- [Oversikt](#oversikt)
- [Oppgavebeskrivelse](#oppgavebeskrivelse)
- [Bygget med](#bygget-med)
- [Funksjoner](#funksjoner)
- [Hvordan bruke prosjektet](#hvordan-bruke-prosjektet)
- [Prosjektstruktur](#prosjektstruktur)
- [Refleksjon](#refleksjon)
- [Ressurser](#ressurser)
- [Forventet resultat](#forventet-resultat)

## Oversikt

Dette prosjektet er et **Google Home Page-inspirert** og en skoleoppgave.  
Målet er å øve på:

- HTML-skjema (input, select, checkbox, radio, textarea)
- Design med CSS, inkludert bakgrunnsbilde over hele siden

Nettsiden etterligner google home page.

## Oppgavebeskrivelse

I denne oppgaven skulle vi lage en nettside som ligner på start siden til google home

Krav til siden:

- Bruke den tilsendte **malen** over hele siden.
- Laste ned bildene som ble tilsent
- Html og Css
- Style skjemaet slik at det passer til **Google Home Page**:
  - Style.css
  - img
  - background color

## Bygget med

- [HTML](https://www.w3schools.com/html/)
- [CSS](https://www.w3schools.com/css/default.asp)
  - Bilde (./)
  - Flexbox
  - Styling av input, select, checkbox, radio, textarea og knapp

## Funksjoner

- Bilder på google home page
- Linker
- Ulike typer høyder/breder
- Tydelig **Google Logo**

## Hvordan bruke prosjektet

Dette prosjektet er lisensiert under MIT-lisensen. 
(MIT-lisensen tillater fri bruk, kopiering, modifisering og distribusjon av programvare av alle.)

1. **Last ned** prosjektet eller klon repoet:
<!-- Bruk backtick i kodebiter. Dette er backtick, ikke apostrof og gåseøyne -->
   ```
   bash
   git clone https://github.com/roykenvgs/test.git
   ```
2. Åpne mappen.
3. Dobbeltklikk på index.html for å åpne siden i nettleseren.
4. Fyll inn skjemaet for å teste layout og funksjon.

## Prosjektstruktur / Mappestruktur

```
.
├── index.html
├── style.css
├── images/
│   └── back.jpg
│   └── bildet1.jpg
└── README.md
```

## Forventet resultat

[Forventet resultat](./Images/forventetResultat.png) <br>
![Image_1](./images/bildet1.jpg)

### Kontakt meg:

[![GitHub Follow Badge](https://img.shields.io/github/followers/roykenvgs?label=follow&style=social)](https://github.com/roykenvgs)

<p align="left">
<a href="#" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg" alt="vikenfylkeskommune" height="30" width="40" /></a>
<a href="mailto:roykenvgs@afk.no" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/gmail.svg" alt="mail" height="30" width="40" /></a>
<a href="#" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg" alt="Roykenvgs" height="30" width="40" /></a>
<a href="#" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/instagram.svg" alt="instagram" height="30" width="40" /></a>
</p>


<p>
Programmer jeg har brukt i prosjektet: <br>
<a href="https://www.w3schools.com/html/" target="_blank">
  <img src="https://iconape.com/wp-content/files/er/371108/svg/371108.svg" alt="html5" width="30" height="30"/>
</a> 
< href="https://www.w3schools.com/css/" target="_blank">
  <img src="https://iconape.com/wp-content/files/dj/370768/png/370768.png" alt="css3" width="30" height="30"/> 
</p>

### Happy Coding! 😊